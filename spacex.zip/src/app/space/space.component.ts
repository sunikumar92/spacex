import { Component, OnInit } from '@angular/core';

import { SpacexService } from '../spacex.service';


@Component({
  selector: 'app-space',
  templateUrl: './space.component.html',
  styleUrls: ['./space.component.css']
})
export class SpaceComponent implements OnInit {
launchYears: any = [];
serverResp: any = [];
years: any = [];
selected:any;
successLaunched: any = [];
eventClass: boolean = false;
evntFalse : boolean = false;
succLauncher: boolean = false;
noRecords:any = ['no records found'];

  constructor(private spacexApi: SpacexService) { }

  ngOnInit() {

  this.getResult();
  }

 // get result from API
  getResult() {
  this.spacexApi.getLaunches()
    .subscribe(data => {

      for (const d of (data as any)) {
        this.years.push({
          year:d.launch_year

        }); 
      }  

      this.serverResp = data;
    }); 
  

    setTimeout(() => {
		var result = this.years.reduce((unique, o) => {
		    if(!unique.some(obj => obj.year === o.year)) {
		      this.launchYears.push(o);
		    }
		    return this.launchYears;
		},[]);
		}, 200); 
		 
}

getLaunch(d){ 
	this.succLauncher = d;
}


// get launched successfull 

getSuccessfullLaunch(d){
if(d === true ){
this.eventClass = true;
this.evntFalse = false;
}
else if(d === false){
this.evntFalse = true;
this.eventClass = false;
}


	this.succLauncher = d;
	this.serverResp = [];
	this.spacexApi.getSuccessLaunches(this.succLauncher)
	.subscribe(resp => {
	if(resp !="")
	this.serverResp = resp;
	
	else
	this.serverResp = this.noRecords;

	}); 
}


// launch years

getLaunchYears(y){
  
	this.spacexApi.getLaunchYearsService(y)
	.subscribe(resp => {
	if(resp !="")
	this.serverResp = resp;
	
	else
	this.serverResp = this.noRecords;
 
	}); 
}

select(item){
this.selected = item;
}

isActive(item){
return this.selected === item;
}
 

}
