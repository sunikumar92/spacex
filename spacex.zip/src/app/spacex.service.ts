import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SpacexService {

  spacexUrl:any = 'https://api.spaceXdata.com/v3/launches?limit=100';
  yearval:any = 2006;
   
  constructor(private http: HttpClient) { }


  getLaunches() {
  return this.http.get(this.spacexUrl);
  }

   getSuccessLaunches(filter:any) { 
   let params = new HttpParams().set ('launch_year',this.yearval)
   								.set ('launch_success',filter)
 	 return this.http.get(this.spacexUrl, {params: params}); 
  }


  // get launch years

  getLaunchYearsService(y) {
  this.yearval =y;
  
  let params = new HttpParams().set ('launch_year',y);
  return this.http.get(this.spacexUrl, {params: params});
  }


}


